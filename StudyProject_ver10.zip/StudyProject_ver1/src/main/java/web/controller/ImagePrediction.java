package web.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ImagePrediction {
	public String ms(String img) throws IOException, InterruptedException {    //img받아온다
		Runtime rt = Runtime.getRuntime();
		Process pc = null;
		String s = null;
		String result= null;
		
		try {
			String python = "C:\\ProgramData\\Anaconda3\\envs\\cpu_env\\python.exe";
			String path = " C:\\python_ML\\ppp.py ";
			String val = img;
			
			String cmd = python + path + val;
			
			pc = rt.exec(cmd);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(pc.getInputStream())) ;
			BufferedReader stdError = new BufferedReader(new InputStreamReader(pc.getErrorStream())) ;
			
			System.out.println("python should be run");
//			System.out.println(cmd);
			String ms = stdInput.readLine();
//			System.out.println(ms);
			
			
			/*while문 :  stdInput(python코드 돌고 출력내용 1줄씩)이 내용이 있으면 계속 읽어*/
			
			while((s = stdInput.readLine()) != null) {
				System.out.println(s); // 1번째꺼
				result = s;		
			}
			
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
			System.exit(-1);
		}finally {
			pc.waitFor();
			pc.destroy();
		}
		return result;
	}
}
