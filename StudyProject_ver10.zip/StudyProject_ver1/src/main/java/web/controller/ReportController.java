package web.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ReportController {

	@RequestMapping(value = "/report.do", method = RequestMethod.GET)
	public String form() {
		return "reportForm";
	}
	/*
	 * 이미지 파일을 업로드하고 제출하면 POST방식으로 전달 서버단의 가상path에 파일 저장 가상path(fff):
	 */

	@RequestMapping(value = "/report.do", method = RequestMethod.POST)
	@ResponseBody
	
	public String upload(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		String fileName = file.getOriginalFilename();
		System.out.println(fileName);
		String path = request.getRealPath("/uploads/"); // 저장되는 path

		String fff = path + fileName;
//		System.out.println("1111123123123");
//		System.out.println("222222222222234434");
//		System.out.println(fff);

		if (!file.isEmpty()) {
			File f = new File(path + fileName);
			try {
				file.transferTo(f);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		request.setAttribute("imgname", fileName);

		ImagePrediction ip = new ImagePrediction();
		String result = null;
		try {
			System.out.println(fff);
			result = ip.ms(fff);
			System.out.println(result);
		


		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

//		mav.addObject("output", result);
//		mav.setViewName("reportResult");
		return result;
	}
}
